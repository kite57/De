﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework.Mvc.Routing;

namespace Nop.Plugin.Payments.Etisalat
{
    public partial class RouteProvider : IRouteProvider
    {
        /// <summary>
        /// Register routes
        /// </summary>
        /// <param name="routeBuilder">Route builder</param>
        public void RegisterRoutes(IRouteBuilder routeBuilder)
        {
            //PDT
            routeBuilder.MapRoute("Plugin.Payments.Etisalat.PDTHandler", "Plugins/PaymentEtisalat/PDTHandler",
                 new { controller = "PaymentEtisalat", action = "PDTHandler" });

            //IPN
            routeBuilder.MapRoute("Plugin.Payments.Etisalat.IPNHandler", "Plugins/PaymentEtisalat/IPNHandler",
                 new { controller = "PaymentEtisalat", action = "IPNHandler" });

            //Cancel
            routeBuilder.MapRoute("Plugin.Payments.Etisalat.CancelOrder", "Plugins/PaymentEtisalat/CancelOrder",
                 new { controller = "PaymentEtisalat", action = "CancelOrder" });

            ////Return
            //routeBuilder.MapRoute("Plugin.Payments.Etisalat.Return",
            //     "Plugins/PaymentTelr/Return/{id}",
            //     new { controller = "PaymentTelr", action = "Return", id = "" });

            ////Return
            //routeBuilder.MapRoute("Plugin.Payments.Etisalat.Failed",
            //     "Plugins/PaymentEtisalat/Failed/{id}",
            //     new { controller = "PaymentEtisalat", action = "Failed", id = "" });

        }

        /// <summary>
        /// Gets a priority of route provider
        /// </summary>
        public int Priority
        {
            get { return -1; }
        }
    }
}
