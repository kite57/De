using Nop.Core.Configuration;

namespace Nop.Plugin.Payments.Etisalat
{
    /// <summary>
    /// Represents settings of the Etisalat Standard payment plugin
    /// </summary>
    public class EtisalatPaymentSettings : ISettings
    {
        /// <summary>
        /// Gets or sets a value indicating whether to use sandbox (testing environment)
        /// </summary>
        public bool UseSandbox { get; set; }

        /// <summary>
        /// Gets or sets a business email
        /// </summary>
        public string BusinessEmail { get; set; }

        /// <summary>
        /// Gets or sets PDT identity tokenGets a route for provider configuration
        /// </summary>
        public string PdtToken { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to pass info about purchased items to Etisalat
        /// </summary>
        public bool PassProductNamesAndTotals { get; set; }

        /// <summary>
        /// Gets or sets an additional fee
        /// </summary>
        public decimal AdditionalFee { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to "additional fee" is specified as percentage. true - percentage, false - fixed value.
        /// </summary>
        public bool AdditionalFeePercentage { get; set; }

        //public string StoreId { get; set; }
        public string AuthenticationKey { get; set; }
        public string PayUri { get; set; }
        //public bool TestMode { get; set; }
        public string ReturnURL { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}

